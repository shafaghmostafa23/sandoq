(function(){
const MEHR=1405*12+6;
window.ADMIN_DATA={
MEHR,
PEOPLE:[
{id:'p1',name:'رضا احمدی',mobile:'۰۹۱۲۳۴۵۶۷۸۹',nid:'۰۰۱۲۳۴۵۶۷۸',status:'active',since:'بهمن ۱۴۰۲'},
{id:'p2',name:'زهرا موسوی',mobile:'۰۹۳۵۱۲۳۴۵۶۷',nid:'۰۰۲۲۴۵۸۸۱۹',status:'active',since:'خرداد ۱۴۰۳'},
{id:'p3',name:'علی رضایی',mobile:'۰۹۱۹۸۷۶۵۴۳۲',nid:'۰۰۶۱۲۳۹۹۷۰',status:'active',since:'مهر ۱۴۰۳'},
{id:'p4',name:'فاطمه حسینی',mobile:'۰۹۱۲۵۵۵۴۴۳۳',nid:'۰۰۴۴۱۲۰۰۸۷',status:'active',since:'فروردین ۱۴۰۲'},
{id:'p5',name:'محمد کاظمی',mobile:'۰۹۳۰۱۱۱۲۲۳۳',nid:'۰۰۸۸۷۷۱۲۳۴',status:'active',since:'آذر ۱۴۰۳'},
{id:'p6',name:'سارا نوری',mobile:'۰۹۱۰۶۶۶۷۷۸۸',nid:'۰۰۳۳۹۰۱۲۴۵',status:'active',since:'دی ۱۴۰۱'},
{id:'p7',name:'حسن جعفری',mobile:'۰۹۱۲۱۰۰۲۰۰۳',nid:'۰۰۱۰۹۹۸۸۷۶',status:'active',since:'۱۴۰۰'},
{id:'p8',name:'مهدی صادقی',mobile:'۰۹۱۵۴۴۴۳۳۲۲',nid:'۰۰۷۷۶۶۵۵۴۴',status:'archived',since:'۱۳۹۹'}],
OFFICES:[
{no:12,name:'نیک‌اندیشان',owner:'p7',acc:'melli',status:'active',since:'اردیبهشت ۱۴۰۱'},
{no:14,name:'همدلی',owner:'p7',acc:'melli',status:'active',since:'مهر ۱۴۰۱'},
{no:7,name:'امید',owner:'p4',acc:'mellat',status:'active',since:'دی ۱۴۰۰'},
{no:9,name:'بهار',owner:'p5',acc:'mellat',status:'active',since:'تیر ۱۴۰۲'},
{no:21,name:'روشنا',owner:'p6',acc:'tejarat',status:'active',since:'بهمن ۱۴۰۲'},
{no:3,name:'قدیم',owner:'p8',acc:'tejarat',status:'archived',since:'۱۳۹۸'}],
ACCS:[
{id:'melli',bank:'بانک ملی',acc:'۰۱۰۲۳۴۵۶۷۸۰۰۱',iban:'IR06 0170 0000 0010 2345 6780 01',holder:'صندوق قرض‌الحسنه نیک‌اندیشان',status:'active',sys:482500000,real:480000000,lastRec:'۲۸ شهریور ۱۴۰۵',cause:''},
{id:'mellat',bank:'بانک ملت',acc:'۵۸۲۰۱۱۴۴۷۰',iban:'IR52 0120 0000 0005 8201 1447 00',holder:'صندوق قرض‌الحسنه امید',status:'active',sys:215300000,real:215300000,lastRec:'۳۰ شهریور ۱۴۰۵',cause:''},
{id:'tejarat',bank:'بانک تجارت',acc:'۴۴۱۰۸۸۲۹۱۶',iban:'IR18 0180 0000 0044 1088 2916 00',holder:'صندوق قرض‌الحسنه روشنا',status:'active',sys:96800000,real:97100000,lastRec:'۲۵ شهریور ۱۴۰۵',cause:''}],
LOANS:[
{no:1042,p:'p1',o:12,amount:50000000,inst:2500000,save:500000,months:20,paid:7,status:'active',first:MEHR-7,acc:'melli',start:'۱ بهمن ۱۴۰۴',dueDay:5},
{no:1037,p:'p2',o:7,amount:30000000,inst:1500000,save:300000,months:20,paid:2,status:'active',first:MEHR-3,acc:'mellat',start:'۱ خرداد ۱۴۰۵',dueDay:5},
{no:1051,p:'p3',o:12,amount:40000000,inst:2000000,save:400000,months:20,paid:4,status:'active',first:MEHR-4,acc:'melli',start:'۱ خرداد ۱۴۰۵',dueDay:5},
{no:1029,p:'p4',o:9,amount:25000000,inst:1250000,save:250000,months:20,paid:12,status:'active',first:MEHR-12,acc:'mellat',start:'۱ شهریور ۱۴۰۴',dueDay:5},
{no:1060,p:'p5',o:21,amount:60000000,inst:3000000,save:500000,months:20,paid:1,status:'active',first:MEHR-1,acc:'tejarat',start:'۱ مرداد ۱۴۰۵',dueDay:5},
{no:1011,p:'p6',o:14,amount:20000000,inst:1000000,save:200000,months:20,paid:20,status:'settled',first:MEHR-20,acc:'melli',start:'۱ دی ۱۴۰۳',dueDay:5}],
DECLS:[
{id:'d1',p:'p1',loan:1042,inst:8,expected:3000000,declared:3000000,date:'۲ مهر ۱۴۰۵ · ۹:۴۱',track:'845219',receipt:'فیش-مهر.jpg',status:'new',acc:'melli',txId:null,events:[]},
{id:'d2',p:'p3',loan:1051,inst:5,expected:2400000,declared:2400000,date:'۲ مهر ۱۴۰۵ · ۸:۱۰',track:'733104',receipt:'',status:'new',acc:'melli',txId:null,events:[]},
{id:'d3',p:'p2',loan:1037,inst:3,expected:1800000,declared:1500000,date:'۱ مهر ۱۴۰۵ · ۲۱:۰۵',track:'690552',receipt:'IMG_2041.jpg',status:'new',acc:'mellat',txId:null,events:[]},
{id:'d4',p:'p4',loan:1029,inst:13,expected:1500000,declared:1500000,date:'۱ مهر ۱۴۰۵ · ۱۱:۲۲',track:'581220',receipt:'receipt.pdf',status:'pending',acc:'mellat',txId:null,events:[]},
{id:'d5',p:'p5',loan:1060,inst:2,expected:3500000,declared:3500000,date:'۳۱ شهریور ۱۴۰۵ · ۱۸:۴۰',track:'610327',receipt:'',status:'pending',acc:'tejarat',txId:null,events:[]},
{id:'d6',p:'p6',loan:1011,inst:20,expected:1200000,declared:1200000,date:'۵ شهریور ۱۴۰۵ · ۱۰:۰۲',track:'498801',receipt:'fish.jpg',status:'confirmed',acc:'melli',txId:'t10',events:[{t:'تایید شد توسط مریم کریمی',s:'۶ شهریور ۱۴۰۵',tone:'ok'}]},
{id:'d7',p:'p1',loan:1042,inst:6,expected:3000000,declared:3000000,date:'۴ شهریور ۱۴۰۵ · ۱۲:۳۰',track:'600012',receipt:'',status:'rejected',acc:'melli',txId:null,reason:'شماره پیگیری در حساب پیدا نشد',events:[{t:'رد شد توسط مریم کریمی',s:'۴ شهریور ۱۴۰۵ · دلیل: شماره پیگیری در حساب پیدا نشد',tone:'err'}]}],
TXS:[
{id:'t1',acc:'melli',date:'۲ مهر ۱۴۰۵',type:'deposit',sign:1,amount:3000000,track:'845219',desc:'واریز قسط',party:'رضا احمدی',o:12,matched:null},
{id:'t2',acc:'melli',date:'۲ مهر ۱۴۰۵',type:'deposit',sign:1,amount:2400000,track:'733104',desc:'واریز قسط',party:'علی رضایی',o:12,matched:null},
{id:'t3',acc:'mellat',date:'۱ مهر ۱۴۰۵',type:'deposit',sign:1,amount:1500000,track:'690552',desc:'واریز',party:'زهرا موسوی',o:7,matched:null},
{id:'t4',acc:'mellat',date:'۱ مهر ۱۴۰۵',type:'deposit',sign:1,amount:1500000,track:'581220',desc:'واریز قسط',party:'فاطمه حسینی',o:9,matched:null},
{id:'t6',acc:'melli',date:'۲۸ شهریور ۱۴۰۵',type:'deposit',sign:1,amount:2500000,track:'552001',desc:'واریز بدون شرح',party:'نامشخص',o:12,matched:null},
{id:'t7',acc:'melli',date:'۲۸ شهریور ۱۴۰۵',type:'deposit',sign:1,amount:2500000,track:'552001',desc:'واریز بدون شرح',party:'نامشخص',o:12,matched:null},
{id:'t8',acc:'melli',date:'۲۰ شهریور ۱۴۰۵',type:'transfer',sign:-1,amount:10000000,track:'900114',desc:'انتقال به بانک ملت',party:'حساب داخلی',o:null,matched:'internal'},
{id:'t9',acc:'mellat',date:'۲۰ شهریور ۱۴۰۵',type:'transfer',sign:1,amount:10000000,track:'900114',desc:'انتقال از بانک ملی',party:'حساب داخلی',o:null,matched:'internal'},
{id:'t10',acc:'melli',date:'۵ شهریور ۱۴۰۵',type:'deposit',sign:1,amount:1200000,track:'498801',desc:'واریز قسط آخر',party:'سارا نوری',o:14,matched:'d6'},
{id:'t5',acc:'tejarat',date:'۱ مرداد ۱۴۰۵',type:'withdraw',sign:-1,amount:60000000,track:'300871',desc:'پرداخت وام ۱۰۶۰',party:'محمد کاظمی',o:21,matched:'loan'}],
AUDIT:[
{user:'مریم کریمی',action:'ویرایش وام',record:'وام ۱۰۴۲',time:'۱ مهر ۱۴۰۵ · ۱۶:۰۲',before:'قسط ۲٬۴۰۰٬۰۰۰',after:'قسط ۲٬۵۰۰٬۰۰۰',reason:'اصلاح طبق قرارداد',kind:'loan'},
{user:'امیر توکلی',action:'ثبت موجودی واقعی',record:'بانک ملی',time:'۲۸ شهریور ۱۴۰۵ · ۱۷:۴۰',before:'—',after:'۴۸۰٬۰۰۰٬۰۰۰',reason:'صورت‌حساب شهریور',kind:'bank'},
{user:'امیر توکلی',action:'ثبت تراکنش',record:'بانک ملی · پیگیری ۵۵۲۰۰۱',time:'۲۸ شهریور ۱۴۰۵ · ۱۷:۲۲',before:'—',after:'واریز ۲٬۵۰۰٬۰۰۰',reason:'—',kind:'bank'},
{user:'امیر توکلی',action:'ثبت تراکنش',record:'بانک ملی · پیگیری ۵۵۲۰۰۱',time:'۲۸ شهریور ۱۴۰۵ · ۱۷:۲۰',before:'—',after:'واریز ۲٬۵۰۰٬۰۰۰',reason:'—',kind:'bank'},
{user:'مریم کریمی',action:'تایید پرداخت',record:'وام ۱۰۱۱ · قسط ۲۰',time:'۶ شهریور ۱۴۰۵ · ۹:۱۵',before:'در انتظار تایید',after:'تایید شده',reason:'—',kind:'pay'},
{user:'مریم کریمی',action:'رد پرداخت',record:'وام ۱۰۴۲ · قسط ۶',time:'۴ شهریور ۱۴۰۵ · ۱۴:۰۰',before:'در انتظار تایید',after:'رد شده',reason:'شماره پیگیری در حساب پیدا نشد',kind:'pay'}]
};
})();
